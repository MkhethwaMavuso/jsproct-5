On this project I revised and tested my ability to use arrays and objects. 
I created a quiz application that tests the user on their knowledge of HTML. 

(1) Determined the purpose of the quiz application, which was educational.
(2) Designed UI elements for displaying questions.
(3) Defined the basic structure of your quiz application using HTML.
(4) Applied CSS to make the application visually appealing.
(5) Ensured responsiveness for different screen sizes.
(6) Wrote JavaScript functions to handle quiz functionalities.
(7) Implemented event listeners to capture user actions.
(8) Developed function to store and manage quiz data.

